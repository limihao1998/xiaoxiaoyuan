package com.google.blockly.android.demo;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MenuFlash {
    private ImageView ivSpin;
    private LinearLayout llMenu;
    public MenuFlash(ImageView ivSpin,LinearLayout llMenu) {
        this.ivSpin=ivSpin;
        this.llMenu=llMenu;
    }
    public void click(boolean state){
        if(state==false) {
            ObjectAnimator o1 = ObjectAnimator.ofFloat(ivSpin, "rotation", 0, 180);
            o1.setDuration(500);
            o1.start();

            llMenu.setVisibility(View.VISIBLE);
            ObjectAnimator o3 = ObjectAnimator.ofFloat(llMenu, "translationX", 200, 0);
            o3.setDuration(500);
            o3.start();
            ObjectAnimator o4 = ObjectAnimator.ofFloat(llMenu, "alpha", 0, 1);
            o4.setDuration(500);
            o4.start();

        }else{
            ObjectAnimator o1 = ObjectAnimator.ofFloat(ivSpin, "rotation", 180, 360);
            o1.setDuration(500);
            o1.start();

            ObjectAnimator o3 = ObjectAnimator.ofFloat(llMenu, "translationX", 0, 200);
            o3.setDuration(500);
            o3.start();
            ObjectAnimator o4 = ObjectAnimator.ofFloat(llMenu, "alpha", 1, 0);
            o4.setDuration(500);
            o4.start();
        }
    }
    public void play(){
        ObjectAnimator l5=ObjectAnimator.ofFloat(ivSpin,"translationX",0,-90,0).setDuration(1000);
        l5.setRepeatCount(ValueAnimator.INFINITE);
        l5.start();
    }
}
