package com.google.blockly.android.demo;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RankActivity extends AppCompatActivity {
        private TextView friends=null;
        private TextView labbers=null;
        private ImageView ivHome;
        private ImageView ivCharts;
        private ImageView ivCommunity;
        private ImageView ivMe;
        private LinearLayout llMenu;
        private ImageView ivSpin;
        private int[] list;
        private boolean state=false;
        private MenuFlash menuFlash;
        private TextView textView1;
        private TextView textView2;

    @Override
        protected void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.labbersrankactivity);
            friends=findViewById(R.id.fra_friends);
            friends.setOnClickListener(listener);
            hide();
            labbersAdapater();
            init();
            menuFlash=new MenuFlash(ivSpin,llMenu);
            menuFlash.play();
            ivSpin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    menuFlash.click(state);
                    if (state==true){
                        state=false;
                    }else{
                        state=true;
                    }
                }
            });
            ivHome.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent();
                    intent.setClass(RankActivity.this,HomePage.class);
                    startActivity(intent);
                }
            });
        }

        public View.OnClickListener listener=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId()==R.id.fra_friends){
                    gotoFriends();
                }else if (view.getId()==R.id.fra_labber){
                    gotolabbers();
                }
            }
        };


        //    天梯榜
        private void gotolabbers() {
            setContentView(R.layout.labbersrankactivity);
            hide();
            friends=findViewById(R.id.fra_friends);
            friends.setOnClickListener(listener);
            init();
            menuFlash=new MenuFlash(ivSpin,llMenu);
            menuFlash.play();
            ivSpin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    menuFlash.click(state);
                    if (state==true){
                        state=false;
                    }else{
                        state=true;
                    }
                }
            });



//        加好友
//        TextView textView=findViewById(R.id.lra_addfriends);
//        textView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });



//        查看资料

//      设置构造器
            labbersAdapater();

        }


        //    好友榜
        private void gotoFriends() {
            setContentView(R.layout.friendsrankactivity);
            hide();
            labbers=findViewById(R.id.fra_labber);
            labbers.setOnClickListener(listener);
            //设置构造器
            friendsAdapater();
            init();

            menuFlash=new MenuFlash(ivSpin,llMenu);
            menuFlash.play();
            ivSpin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    menuFlash.click(state);
                    if (state==true){
                        state=false;
                    }else{
                        state=true;
                    }
                }
            });




//        查看资料


        }

        private void friendsAdapater() {
            List<Map<String,Object>>list=indata1();
            friendsAdapater friendsAdapater=new friendsAdapater(this,R.layout.friendsranklistactivity,list);
            ListView listView=findViewById(R.id.lv_ranklistfriends);
            listView.setAdapter(friendsAdapater);
        }
        private void labbersAdapater(){
            List<Map<String,Object>>list=indata2();
            labbersAdapater labbersAdapater=new labbersAdapater(this,R.layout.labbersranklistactivity,list);
            ListView listView=findViewById(R.id.lv_ranklistlabbers);
            listView.setAdapter(labbersAdapater);
        }



        //数据
        private List<Map<String, Object>> indata1(){
            String name[]={"刘阳","百里","陈生","端木","公羊","黄龙","即墨"};
            String marks[]={"100","99","98","97","96","95","94"};
            List<Map<String,Object>>list=new ArrayList<Map<String,Object>>();
            for (int i=0;i<6;i++){
                Map<String,Object>map=new HashMap<String,Object>();
                map.put("image",R.mipmap.tou);
                map.put("name",name[i]);
                map.put("marks",marks[i]);
                list.add(map);
            }
            return list;
        }
        private List<Map<String, Object>> indata2(){
            String name[]={"刘阳","百里","陈生","端木","公羊","黄龙","即墨"};
            String marks[]={"100","99","98","97","96","95","94"};
            List<Map<String,Object>>list=new ArrayList<>();
            for (int i=0;i<6;i++){
                Map<String,Object>map=new HashMap<>();
                map.put("image",R.mipmap.tou);
                map.put("name",name[i]);
                map.put("marks",marks[i]);
                map.put("friends","加好友");
                list.add(map);
            }
            return list;
        }

        //隐藏状态栏
        private void hide(){
            Window window = getWindow();
            ActionBar actionBar = getSupportActionBar();
            if (actionBar != null) {
                actionBar.hide();
            }
            //隐藏状态栏
            //定义全屏参数
            int flag= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            //设置当前窗体为全屏显示
            window.setFlags(flag, flag);
        }

        //好友构造器
        private class friendsAdapater extends BaseAdapter{
            private Context context;
            private int Id;
            private List<Map<String, Object>> data;

            public friendsAdapater(Context context,int Id,List<Map<String, Object>> data){
                this.context=context;
                this.Id=Id;
                this.data=data;
            }

            @Override
            public int getCount() {
                return data.size();
            }

            @Override
            public Object getItem(int postion) {
                return data.get(postion);
            }

            @Override
            public long getItemId(int postion) {
                return postion;
            }

            @Override
            public View getView(int position, View view, ViewGroup viewGroup) {
                LayoutInflater inflater=LayoutInflater.from(context);
                view=inflater.inflate(Id,null);
                ImageView image=view.findViewById(R.id.fra_image);
                TextView name=view.findViewById(R.id.fra_name);
                TextView marks=view.findViewById(R.id.fra_marks);
                //获取数据
                Map<String, Object> map = data.get(position);
                image.setImageResource((int)map.get("image"));
                name.setText((String)map.get("name"));
                marks.setText((String)map.get("marks"));
                return view;
            }
        }

        //天梯榜构造器
        private class labbersAdapater extends BaseAdapter {
            private Context context;
            private int Id;
            private List<Map<String, Object>> data;

            public labbersAdapater(Context context,int Id,List<Map<String, Object>> data){
                this.context=context;
                this.Id=Id;
                this.data=data;
            }

            @Override
            public int getCount() {
                return data.size();
            }

            @Override
            public Object getItem(int postion) {
                return data.get(postion);
            }

            @Override
            public long getItemId(int postion) {
                return postion;
            }

            @Override
            public View getView(int position, View view, ViewGroup viewGroup) {
                LayoutInflater inflater= LayoutInflater.from(context);
                view=inflater.inflate(Id,null);
                ImageView image=view.findViewById(R.id.lra_image);
                TextView name=view.findViewById(R.id.lra_name);
                TextView labber=view.findViewById(R.id.lra_labber);
                TextView add=view.findViewById(R.id.lra_addfriends);
                //获取数据
                Map<String, Object> map = data.get(position);
                image.setImageResource((int)map.get("image"));
                name.setText((String)map.get("name"));
                labber.setText((String)map.get("marks"));
                add.setText((String)map.get("friends"));
                return view;
            }
        }

        //边框
         private void init(){
        ivHome=findViewById(R.id.iv_HomePage);
        ivCharts=findViewById(R.id.iv_charts);
        ivCommunity=findViewById(R.id.iv_community);
        ivMe=findViewById(R.id.iv_me);
        llMenu=findViewById(R.id.ll_menu);
        ivSpin=findViewById(R.id.iv_spin);
        list= new int[]{R.id.iv_HomePage, R.id.iv_charts, R.id.iv_community, R.id.iv_me};
    }


}