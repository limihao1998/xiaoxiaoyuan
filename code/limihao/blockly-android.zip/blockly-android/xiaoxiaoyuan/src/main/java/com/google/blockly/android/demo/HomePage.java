package com.google.blockly.android.demo;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class HomePage extends AppCompatActivity {
    private AudioManager audioManager=null;
    private MediaPlayer player=null;

    private ImageView ivMonster;
    private ImageView ivCreat;
    private ImageView ivAtrs;
    private ImageView ivTv;
    private ImageView ivSetting;
    private ImageView ivSpin;
    private LinearLayout llMenu;
    private ImageView ivHome;
    private ImageView ivCharts;
    private ImageView ivCommunity;
    private ImageView ivMe;
    private int[] list;
    private boolean state=false;
    private boolean volume=true;
    private void init(){
        ivCreat=findViewById(R.id.iv_creat);
        ivAtrs=findViewById(R.id.iv_arts);
        ivTv=findViewById(R.id.iv_tv);
        ivSetting=findViewById(R.id.iv_setting);
        ivSpin=findViewById(R.id.iv_spin);
        ivHome=findViewById(R.id.iv_HomePage);
        ivCharts=findViewById(R.id.iv_charts);
        ivCommunity=findViewById(R.id.iv_community);
        ivMe=findViewById(R.id.iv_me);
        llMenu=findViewById(R.id.ll_menu);
        ivMonster=findViewById(R.id.iv_monster);
        list= new int[]{R.id.iv_HomePage, R.id.iv_charts, R.id.iv_community, R.id.iv_me};
    }

    private void show(){
        ObjectAnimator l1=ObjectAnimator.ofFloat(ivCreat,"translationY",-1500,0,-500,0).setDuration(2000);
        l1.start();

        ObjectAnimator l2=ObjectAnimator.ofFloat(ivAtrs,"translationY",-500,0,-200,0).setDuration(2000);
        l2.start();

        ObjectAnimator l3=ObjectAnimator.ofFloat(ivTv,"translationY",1500,0,300,0).setDuration(2000);
        l3.start();

        ObjectAnimator l4=ObjectAnimator.ofFloat(ivMonster,"translationY",-2000,0,-600,0,-300,0).setDuration(2200);
        l4.start();

        ObjectAnimator l5=ObjectAnimator.ofFloat(ivSpin,"translationX",0,-90,0).setDuration(1000);
        l5.setRepeatCount(ValueAnimator.INFINITE);
        l5.start();



    }

    private void menu(){
        if(state==false) {
            ObjectAnimator o1 = ObjectAnimator.ofFloat(ivSpin, "rotation", 0, 180);
            o1.setDuration(500);
            o1.start();

            llMenu.setVisibility(View.VISIBLE);
            ObjectAnimator o3 = ObjectAnimator.ofFloat(llMenu, "translationX", 200, 0);
            o3.setDuration(500);
            o3.start();
            ObjectAnimator o4 = ObjectAnimator.ofFloat(llMenu, "alpha", 0, 1);
            o4.setDuration(500);
            o4.start();
            state=true;

        }else{
            ObjectAnimator o1 = ObjectAnimator.ofFloat(ivSpin, "rotation", 180, 360);
            o1.setDuration(500);
            o1.start();

            ObjectAnimator o3 = ObjectAnimator.ofFloat(llMenu, "translationX", 0, 200);
            o3.setDuration(500);
            o3.start();
            ObjectAnimator o4 = ObjectAnimator.ofFloat(llMenu, "alpha", 1, 0);
            o4.setDuration(500);
            o4.start();


            state=false;
        }
    }

    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            creat();
            super.handleMessage(msg);
        }
    };

    private Handler loop=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            ObjectAnimator o1=ObjectAnimator.ofFloat(ivCreat,"translationY",0,-100,0).setDuration(3000);
            o1.setRepeatCount(ValueAnimator.INFINITE);
            o1.start();

            ObjectAnimator o2=ObjectAnimator.ofFloat(ivAtrs,"translationY",0,-60,0).setDuration(3000);
            o2.setRepeatCount(ValueAnimator.INFINITE);
            o2.start();

            ObjectAnimator o3=ObjectAnimator.ofFloat(ivTv,"translationY",0,60,0).setDuration(3000);
            o3.setRepeatCount(ValueAnimator.INFINITE);
            o3.start();
            super.handleMessage(msg);
        }
    };
    private void creat(){
        Intent intent=new Intent();
        intent.setClass(HomePage.this,LuaActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }
    private void hidTitle(){
        Window window = getWindow();
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        //隐藏状态栏
        //定义全屏参数
        int flag= WindowManager.LayoutParams.FLAG_FULLSCREEN;
        //设置当前窗体为全屏显示
        window.setFlags(flag, flag);
    }
    private void playMusic(){
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        player=MediaPlayer.create(HomePage.this,R.raw.bgmusic);
        player.setLooping(true);
        player.start();
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        //播放音乐
        playMusic();
        //隐藏状态栏方法
        hidTitle();
        //初始化菜单列表
        init();
        //弹出首页控件操作
        //弹出菜单操作
        ivSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(volume==true){
                    ivSetting.setImageResource(R.mipmap.close);
                    volume=false;
                    player.pause();
                }else{
                    ivSetting.setImageResource(R.mipmap.open);
                    volume=true;
                    player.start();
                }
            }
        });

        ivSpin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                menu();
            }
        });

        ivMonster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        ivCreat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator o1=ObjectAnimator.ofFloat(ivCreat,"scaleY",1,3,1).setDuration(800);
                o1.start();
                ObjectAnimator o2=ObjectAnimator.ofFloat(ivCreat,"scaleX",1,3,1).setDuration(800);
                o2.start();
                handler.sendEmptyMessageDelayed(0,800);

            }
        });

        ivAtrs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        ivTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        show();
        loop.sendEmptyMessageDelayed(0,2000);
    }
}
